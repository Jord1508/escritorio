existencias = (1,'FC001',5,15,75)
data = ()
ope = [(1,'FC001',5,15,75),(1,'FC001',5,15,75)]

print(existencias)
print(ope)

def operacion():
    data = input('A\n>>'),input('B\n>>')
    print(data)

operacion()