from PyQt5 import QtWidgets, uic , QtGui
from PyQt5 import QtGui
from Vista.vUsuario import *
from Vista.vProducto import *

class VentanaPrincipal(QtWidgets.QMainWindow):
    def __init__(self,parent = None):
        super(VentanaPrincipal,self).__init__(parent)
        self.setWindowIcon(QtGui.QIcon("UI/imagenes/venta.png"))
        uic.loadUi("UI/vPrincipal.ui",self)
        self.btnPUsers.clicked.connect(self.btn_2)
        self.btnClientes.clicked.connect(self.btn_3)
        
        self.btnUsuarioVentana.clicked.connect(self.abrirVentanaUsuario)
        self.btnClientesVentana.clicked.connect(self.abrirVentanaClientes)
        self.DatosUsuario()
        
    def btn_2(self):
        self.container.setCurrentIndex(1)
        
    def btn_3(self):
        self.container.setCurrentIndex(2)

    def abrirVentanaUsuario(self):
        vUsuario = VentanaUsuario(self)
        vUsuario.show()
    
    def abrirVentanaClientes(self):
        vclientes = VentanaProductos(self)
        vclientes.show()
        
    def DatosUsuario(self):
        #Cargar Lista de usuarios
        items = tablaUsuario()
        self.tblMainUsuarios.setRowCount(len(items))
        self.tblMainUsuarios.verticalHeader().setVisible(False)
        self.tblMainUsuarios.setVerticalScrollBarPolicy(False)
        
        i = 0
        for usuario in items:
            self.tblMainUsuarios.setItem(i, 0, QtWidgets.QTableWidgetItem(usuario[1]))
            self.tblMainUsuarios.setItem(i, 1, QtWidgets.QTableWidgetItem(usuario[2]))
            i += 1
        
        self.txtTotalUsuario.setText(f'{i} Usuarios')
        
        #Cargar Data de Cantidad de Cargos 
        
        lista = TablaCargos()
        
        self.txtTotalCargos.setText(f'{len(lista)} Cargos')
