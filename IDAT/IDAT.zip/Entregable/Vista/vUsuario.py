from PyQt5 import QtWidgets, uic
from PyQt5 import QtGui
import pyodbc
from DB.conexion import *
from Controlador.usuario import *


class VentanaUsuario(QtWidgets.QMainWindow):

    def __init__(self,parent = None):
        super(VentanaUsuario,self).__init__(parent)
        self.setWindowIcon(QtGui.QIcon("UI/imagenes/venta.png"))
        uic.loadUi("UI/vUsuario.ui", self)
        
        self.cargarTabla()
        self.llenar_comboBox2()
        
        #Pagina 1 
        self.btnMain.clicked.connect(self.btn_1)
        self.btnRefrescar.clicked.connect(self.cargarTabla)
        #Pagina 2
        self.btnCrear.clicked.connect(self.btn_2)
        self.btn_insertData.clicked.connect(self.InsertarUsuario)
        #Pagina 3
        self.btnBuscar.clicked.connect(self.btn_3)
        self.btnActualizar.clicked.connect(self.btn_4)
        self.btnEliminar.clicked.connect(self.btn_5)
        self.btnXa.clicked.connect(self.btn_6)
        self.btnXCerrar.clicked.connect(self.btn_exit)
        
        
    #FUNCIONES DE BOTONES LATERALES
    def btn_1(self):
        self.container.setCurrentIndex(0)
    
    def btn_2(self):
        self.container.setCurrentIndex(1)
    
    def btn_3(self):
        self.container.setCurrentIndex(2)
    def btn_4(self):
        self.container.setCurrentIndex(3)
    def btn_5(self):
        self.container.setCurrentIndex(4)
    def btn_6(self):
        self.container.setCurrentIndex(5)
    def btn_exit(self):
        self.close()
        return ' Boton de salida'
    
    #FUNCIONES DE CARGA
    def cargarTabla(self):
        items = tablaUsuario()
        self.tblUsuario.setRowCount(len(items))
        i = 0
        for usuario in items:
            self.tblUsuario.setItem(i, 0, QtWidgets.QTableWidgetItem(usuario[0]))
            self.tblUsuario.setItem(i, 1, QtWidgets.QTableWidgetItem(usuario[1]))
            self.tblUsuario.setItem(i, 2, QtWidgets.QTableWidgetItem(usuario[2]))
            i += 1
        print(i)
        self.txtTotal_item.setText(f'{i} Usuarios')
        
    def InsertarUsuario(self):
        if self.validar() == "":
            a = self.inputCodigo.text()
            b = self.inputNombre.text()
            c = self.inputCargo.currentText()
            d = self.inputClave.text()
            NuevoUsuario(a,b,c,d)
            self.inputCodigo.clear()
            self.inputNombre.clear()
            self.inputCargo.setCurrentIndex(0)
            self.inputClave.clear()
            self.container.setCurrentIndex(0)
        else:
            QtWidgets.QMessageBox.information(self, "Registrar Cliente", "Error en " + self.validar(), QtWidgets.QMessageBox.Ok)
        
        
    def validar(self):
        if self.inputCodigo.text() == "":
            self.inputCodigo.setFocus()
            return "Codigo del cliente...!!!"
        elif self.inputNombre.text() == "":
            self.inputNombre.setFocus()
            return "Nombre del cliente...!!!"
        elif self.inputCargo.currentText() == "Seleccione":
            self.inputCargo.setFocus()
            return "Cargo Paterno del cliente...!!!"
        elif self.inputClave.text() == "":
            self.inputClave.setFocus() 
            return "Password Materno del cliente...!!!"
        else:
            return ""
        
    #ARREGLOS DE USUARIOS
    def llenar_comboBox2(self):        
        etiquet = []
        lista = TablaCargos()
        
        for item in lista:
            etiquet.append(item[1])
            
        print(etiquet)
        self.inputCargo.addItems(etiquet)
        self.inputCargo_3.addItems(etiquet)

# Estilos
# background-color: rgb(0, 170, 255);
    
